$(document).ready(function() {

	$(document).click(function() {
		$('#target').effect(애니메이션의 종류);
	});
	
});